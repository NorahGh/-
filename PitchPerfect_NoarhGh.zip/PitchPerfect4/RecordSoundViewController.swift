//
// RecordSoundViewController.swift
//  PitchPerfect3
//
//  Created by juhainah on 29/03/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//
// ---------------------------------------------------------------------------

// الاسم : نوره عبدالله الغميجان.
// Name: Norah Abduallah Al-Ghomijan.

// ---------------------------------------------------------------------------


import UIKit
import AVFoundation
class RecordSoundViewController: UIViewController, AVAudioRecorderDelegate {
    
    var audioRecorder: AVAudioRecorder!
    
    @IBOutlet weak var Recording: UIButton!
    @IBOutlet weak var StopRecording: UIButton!
    @IBOutlet weak var RecordingLable: UILabel!
    
    // Mark: دالة لتغيير حالة التسجيل.
    
    func ChangeRecordingStatus (RecordButton: Bool, StopButton: Bool, recordingLable: String)
    {
        RecordingLable.text = recordingLable
        StopRecording.isEnabled = StopButton
        Recording.isEnabled = RecordButton
    }
    
    // ---------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // to disable the StopButton so, it will not cause a runtime error, when the user accidentally tab on StopButton before Recording.
        // لتعطيل زر ايقاف التشغيل StopButton حتى لا يتسبب بخطأ أثناء تشغيل التطبيق runtime error حينما يضغط عليه المستخدم (خطأً) قبل أن يضغط زر التسجيل.
        
        ChangeRecordingStatus (RecordButton: true, StopButton: false, recordingLable: "اضغط للتسجيل.. \n Tab to record..")
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // ---------------------------------------------------------------------------
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    // ---------------------------------------------------------------------------
    
    // Mark: function to record sounds..
    
    @IBAction func RecordingAudio(_ sender: Any) {

        ChangeRecordingStatus(RecordButton: false, StopButton: true, recordingLable: "جاري التسجيل.. \n recording in progress..")
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.default, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
        
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    // ---------------------------------------------------------------------------
    
    @IBAction func StopRecording(_ sender: Any) {
        
        audioRecorder.stop()
        
        ChangeRecordingStatus(RecordButton: true, StopButton: false, recordingLable: " اضغط، للتسجيل من جديد..\n Tab, to start recording again")
        
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
    // ---------------------------------------------------------------------------
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool)
    {
        if flag
        {
            performSegue(withIdentifier: "StopRecording", sender: audioRecorder.url)
        }
        else
        {
            print ("لم يتم التسجيل، هنالك عطل ما!!")
        }
    }
    
    // ---------------------------------------------------------------------------
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "StopRecording"
        {
            let PlaySoundsVC = segue.destination as! PlaySoundsViewController
            let RecordedAudioURL = sender as! URL
            PlaySoundsVC.recordedAudioURL = RecordedAudioURL
        }
    }
}

