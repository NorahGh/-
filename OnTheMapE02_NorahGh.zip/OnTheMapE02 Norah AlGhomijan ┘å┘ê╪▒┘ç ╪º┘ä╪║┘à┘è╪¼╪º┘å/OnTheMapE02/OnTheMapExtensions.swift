//
//  OnTheMapExtensions.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 13/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreLocation

extension UIViewController
{
    func showAlert (message: String)
    {
        let alert = UIAlertController(title: "Alert تنبيه", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func activityIndicator() -> UIActivityIndicatorView
    {
        let loading = UIActivityIndicatorView(style: .gray)
        
        self.view.addSubview(loading)
        self.view.bringSubviewToFront(loading)
        loading.center = self.view.center
        loading.hidesWhenStopped = true
        loading.startAnimating()
        return loading
    }
}

extension MKMapViewDelegate
{
    func settingAnnotation ( _ pinView : MKPinAnnotationView?)
    {
        pinView?.image = #imageLiteral(resourceName: "icon_pin")
        pinView?.canShowCallout = true
        pinView?.pinTintColor = .red
        pinView?.rightCalloutAccessoryView = UIButton(type: UIButton.ButtonType.detailDisclosure )
        
    }
}
