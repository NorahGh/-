//
//  UdacityAPI.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import MapKit
import UIKit

class UdacityAPI
{
    static var user = UserInfo()
    static var sessionId : String?
    
    enum Endpoints
    {
        static let base = "https://onthemap-api.udacity.com/v1"
        
        case session
        case postLocation
        case userPublicData ( String )
        case retrieveLocations (Int,String)
        
        var stringURL: String
        {
            switch self
            {
            case .session :
                return Endpoints.base + "/session"
            case .postLocation:
                return Endpoints.base + "/StudentLocation"
            case let .userPublicData(key):
                return Endpoints.base + "/users" + "/\(key)"
            case let .retrieveLocations (limit, order):
                return Endpoints.base + "/StudentLocation" + "?limit=\(limit)" + "&order=\(order)"
            }
        }
        
        var url: URL { return URL(string: stringURL)!}
        
    }
    
    class func postSession (userName: String , password: String , completion: @escaping(HTTPURLResponse?,LoginDataResponse?, Error?)-> Void)
    {
        
        var request = URLRequest(url: Endpoints.session.url)
        
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = "{\"udacity\": {\"username\": \"\(userName)\", \"password\":\"\(password)\"}}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) {
            (data, response, error) in
            
            guard let response = response as? HTTPURLResponse else {DispatchQueue.main.async {  completion(nil, nil, error) }; return }
            guard let data = data else {  DispatchQueue.main.async {  completion(response, nil, error) }; return }
            
            let range = Range(uncheckedBounds: (lower: 5, upper: data.count))
            let newData = data.subdata(in: range)
            do
            {
                let dataObj = try JSONDecoder().decode(LoginDataResponse.self,from: newData)

                
                user.sessionId = dataObj.session?.id
                user.uniqueKey = dataObj.account?.key
                
                DispatchQueue.main.async { completion (response, dataObj, nil) }
            } catch {  DispatchQueue.main.async { completion(response, nil, error) } }
        }
        task.resume()
    }
    
    class func deleteSession (completion: @escaping(Error?)-> Void)
    {
        //        parameters:  handler       فقط لإنشاء جلسة لتسجيل الخروج
        
        
        var request = URLRequest(url: Endpoints.session.url)
        request.httpMethod = "DELETE"
        
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! { if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie } }
        if let xsrfCookie = xsrfCookie { request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN") }
        
        let task = URLSession.shared.dataTask(with: request)
        {
            (data, response, error) in
            guard data != nil else
            { DispatchQueue.main.async { completion(error) }; return }
//            let range = Range(uncheckedBounds: (lower: 5, upper: data.count))
//            let newData = data.subdata(in: range)
//            print(String(data: newData, encoding: .utf8)!)
            DispatchQueue.main.async { completion(nil) }
        }
        task.resume()
    }
    
    
    
    class func getStudentLocations (completion: @escaping (Bool, Error?) -> Void)
    {
        
        let request = URLRequest(url: Endpoints.retrieveLocations(100, "-updatedAt").url)
        
        let task = URLSession.shared.dataTask(with: request)
        { (data, response, error) in
            
            guard let response = response as? HTTPURLResponse else
            { DispatchQueue.main.async { completion(false,nil) }; return }
            
            if response.statusCode >= 200 && response.statusCode < 300
            {
                guard let data = data else
                { DispatchQueue.main.async { completion(false,error) }; return }
                
                do {
                    let responseDictionary = try JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
                    guard let results = responseDictionary["results"] as? [Any] else { DispatchQueue.main.async { completion(false,nil)} ;return }
                    let resultsASdata = try JSONSerialization.data(withJSONObject: results, options: [])
                    let responseObj = try JSONDecoder().decode([StudentLocation].self, from: resultsASdata)
                    SharedData.shared.pins = responseObj
                    DispatchQueue.main.async { completion(true,nil)}
                    
                } catch { DispatchQueue.main.async { completion(false,error)} }
            }
        }
        task.resume()
    }
    
    class func getUserData (completion: @escaping (Error?) -> Void)
    {
        let request = URLRequest(url: Endpoints.userPublicData(user.uniqueKey ??  "76ruyf").url)
        
        let task = URLSession.shared.dataTask(with: request)
        { (data, response, error) in
            guard let data = data else { DispatchQueue.main.async { completion(error) }; return }
            let newData = data.subdata(in: 5..<data.count)
            do
            {
                let dataObj = try JSONSerialization.jsonObject(with: newData, options: []) as? [String:Any]
                user.firstName = dataObj?["first_name"] as? String ?? ""
                user.lastName = dataObj?["last_name"] as? String ?? ""
                 DispatchQueue.main.async { completion(nil) }
            } catch { DispatchQueue.main.async { completion(error) } }
        }
        task.resume()
    }
    
    class func postLocation (student : StudentLocation?, completion: @escaping (Error?) -> Void)
    {
        //        parameters: link, coordinates, location name, handler      لإنشاء موقع (دبوس) جديد لطالب جديد
        let body = StudentLocation(createdAt: "", firstName: user.firstName, lastName: user.lastName, latitude: student!.latitude!, longitude: student!.longitude!, mapString: student!.mapString!, mediaURL: student!.mediaURL!, objectId: nil, uniqueKey: user.uniqueKey, updatedAt: "")
        
        var request = URLRequest(url: Endpoints.postLocation.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do {
            request.httpBody = try JSONEncoder().encode(body)
        } catch { completion( self.makingError(errorString: "couldn't post your location \n \(error)", code: 0)) }
        
        let task = URLSession.shared.dataTask(with: request)
        { (data, response, error) in
            
            guard let response = response as? HTTPURLResponse else
            { let error = self.makingError(errorString: "connection Failed", code: 0)
                DispatchQueue.main.async { completion( error) }; return }
            
            if (response.statusCode >= 200 && response.statusCode < 300)
            {   DispatchQueue.main.async { completion(nil) }    }
            else
            {
                guard let error = error else
                { let error2 = self.makingError(errorString: "connection Failed", code: 0)
                    DispatchQueue.main.async { completion(error2) }
                    return  }
                let error3 = self.makingError(errorString: "couldn't post your location \n \(error.localizedDescription)", code: 0)
                DispatchQueue.main.async { completion(error3) }
            }
        }
        task.resume()
        
    }
    
    class func makingError (errorString: String, code: Int) -> Error
    {   return NSError(domain: errorString, code: code, userInfo: nil)}
}
