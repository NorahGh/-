//
//  NavigationBarVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit
import MapKit

protocol Refresh
{   func refreshLocations ()
    func updatePins ()
}



class NavigationBarVC: UIViewController , Refresh
{
    var pins : [ StudentLocation ] { return SharedData.shared.pins }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        setupBarLeft ()
        setupBarCenter()
        setupBarRight()
        loadPins ()
        
    }
    
    func loadPins ()
    {
        let startLoading = activityIndicator()
        startLoading.startAnimating()
        UdacityAPI.getStudentLocations(completion: handleGetStudentLocations(success:error:))
        startLoading.stopAnimating()
    }
    
    func handleGetStudentLocations (success: Bool, error: Error? )
    {
        if !( success )
        {   guard let error = error else
            { self.showAlert(message: "Problem with network connection "); return }
            
            self.showAlert(message: "Failed on downloading student locations \n \(error.localizedDescription)")
        }
        else
        { updatePins() }
    }
    
    func refreshLocations ()
    {   fatalError() }
    
    func updatePins()
    {   fatalError() }
    
    func setupBarLeft()
    {
        let logoutButton = UIButton(type: .system)
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.addTarget(self, action: #selector(NavigationBarVC.logout), for: .touchDown)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: logoutButton)
    }
    
    func setupBarCenter()
    {
        navigationItem.title = "On The Map"
    }
    
    func setupBarRight ()
    {
        let reloadButton = UIButton(type: .custom)
        reloadButton.setImage(#imageLiteral(resourceName: "icon_refresh"), for: .normal)
        reloadButton.addTarget(self, action: #selector(refresh(_:)), for: .touchDown)
        
        let postLoc = UIButton(type: .custom)
        postLoc.setImage(#imageLiteral(resourceName: "icon_addpin"), for: .normal)
        postLoc.addTarget(self, action: #selector(postLocation(_:)), for: .touchDown)
        
        let spacing = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        spacing.width = 12.0
        
        let buttons = [UIBarButtonItem(customView: postLoc), spacing, UIBarButtonItem(customView: reloadButton)]
        
        navigationItem.rightBarButtonItems = buttons
    }
    
    @objc func logout (_ sender:UIButton)
    {
        UdacityAPI.deleteSession
        { (error) in
            guard let error = error else
            {   self.dismiss(animated: true, completion: nil); return }
            self.showAlert(message: "Logout failed \n \(error.localizedDescription)")
        }
    }
    
    @objc func postLocation ( _ sender: UIButton)
    {
        let navigationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PostLocationNavigationC") as! UINavigationController
        present(navigationVC, animated: true, completion: nil)
    }
    
    @objc func refresh ( _ sender: UIButton)
    { refreshLocations()    }
    
    
}
