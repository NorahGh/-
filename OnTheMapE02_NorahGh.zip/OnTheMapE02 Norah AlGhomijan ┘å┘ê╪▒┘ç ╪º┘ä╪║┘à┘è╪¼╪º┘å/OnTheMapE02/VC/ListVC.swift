//
//  ListVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit
import CoreGraphics

class ListVC: NavigationBarVC
{
    let cellID = "cellListVC"
    var pin : StudentLocation!
    var listPins: [StudentLocation] = [] { didSet { tableView.reloadData() } }

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad()
    {   super.viewDidLoad()  }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if listPins.isEmpty
        { refreshLocations() }
        else
        { updatePins() }
    }
    
    override func refreshLocations()
    {   loadPins()  }
    
    override func updatePins ()
    {
        for pin in SharedData.shared.pins
        {
            if !( self.listPins.contains(where: { (student) -> Bool in
                student.firstName == pin.firstName && student.lastName == pin.lastName}) )
            { self.listPins.append(pin) }
        }
    }
}


extension ListVC:  UITableViewDataSource, UITableViewDelegate
{
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
     {  return listPins.count }
    
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        cell.textLabel?.text = (listPins[indexPath.row].firstName ?? "") + "" + (listPins[indexPath.row].lastName ?? "")
        cell.detailTextLabel?.text = listPins[indexPath.row].mediaURL
        cell.imageView?.image = #imageLiteral(resourceName: "icon_pin")
        return cell
    }
    
    
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
     {
        if let pinURL = URL(string: listPins[indexPath.row].mediaURL!)
        {   UIApplication.shared.open(pinURL, options: [:], completionHandler: nil) }
        else
        {   showAlert(message: "Couldn't open the link, check if it's correct. \n لا أستطيع فتح الرابط") }
    }
    
}
