//
//  PostLocationVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 12/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreLocation

class PostLocationVC: UIViewController
{
    var coordinatesVar: CLLocationCoordinate2D!
    var student : StudentLocation?
    
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var linkField: UITextField!
    @IBOutlet weak var findButton: UIButton!
    @IBOutlet weak var loading: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(self.loading)
        self.view.bringSubviewToFront(self.loading)
        freezeUI(false)
    }
    
    @IBAction func findLocation(_ sender: Any)
    {   //1
        if locationField.text != nil && linkField.text != nil , locationField.text != "" && linkField.text != ""
        {  freezeUI(true)
           UdacityAPI.getUserData(completion: self.handlingGetUserDataResponse(error:)) }
        else
        {   self.showAlert(message: "You should fill the location and the link fields") }
        
        freezeUI(false)
    }
    
    
    func handlingGetUserDataResponse ( error: Error?)
    {   //2
        guard let error = error else
        {   self.geocoding(location: self.locationField.text!, completion: self.handlingGeocodingResponse(coordinate:error:))
            return }
        self.showAlert(message: "failed to download user public data. \n \(error.localizedDescription)")
    }
    
    
    func geocoding (location: String, completion: @escaping (CLLocationCoordinate2D?, Error?) -> Void )
    {   // 3
        freezeUI(true)
        CLGeocoder().geocodeAddressString(location)
        { (marks, error) in
            guard let marks = marks else
            { DispatchQueue.main.async { completion(nil,error) }; return }
            
            let coordinates = marks.first?.location?.coordinate
            
            DispatchQueue.main.async { completion(coordinates,nil) }
        }
        freezeUI(false)
        
    }
    
    
    func handlingGeocodingResponse ( coordinate: CLLocationCoordinate2D? , error: Error? )
    {   // 4
        guard let coordinate = coordinate else
        {   self.showAlert(message: "Check if the location is correct.")
            return }
        
        self.coordinatesVar = coordinate
        self.student?.latitude = coordinate.latitude
        self.student?.longitude = coordinate.longitude
        self.student?.mediaURL = self.linkField.text!
        self.student?.mapString = self.locationField.text!
        sendingDataToVC()
    }
    
    func sendingDataToVC ()
    {
        freezeUI(false)
        let newStudent = StudentLocation.init(createdAt: "", firstName: nil, lastName: nil, latitude: coordinatesVar.latitude, longitude: coordinatesVar.longitude, mapString: self.locationField.text, mediaURL: self.linkField.text, objectId: "", uniqueKey: "", updatedAt: "")
        self.performSegue(withIdentifier: "studentLocationMap", sender: newStudent)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {   //
        
        if let destinationVC = segue.destination as? SubmitVC , segue.identifier == "studentLocationMap"
        {   destinationVC.coordinates = self.coordinatesVar
            destinationVC.student = sender as? StudentLocation }
        
    }
 
    @IBAction func Cancel(_ sender: Any)
    {   self.dismiss(animated: true, completion: nil) }
    
    
    func freezeUI (_ freeze : Bool)
    {
        if (freeze)
        {   self.loading.startAnimating()   }
        else {  self.loading.stopAnimating()    }
        
        self.locationField.isUserInteractionEnabled = !freeze
        self.linkField.isUserInteractionEnabled = !freeze
        self.findButton.isEnabled = !freeze
    }
}

