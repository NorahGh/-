//
//  MapVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class MapVC: NavigationBarVC
{
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.mapView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        if pins.isEmpty
        { loadPins() }
        else
        { updatePins() }
    }
    
    override func refreshLocations ()
    {   loadPins()  }
    
    override func updatePins ()
    {
        var totalPins = [MKPointAnnotation]()
        
        for singlePin in pins
        {
            let lat = CLLocationDegrees(exactly: singlePin.latitude ?? 0)
            let long = CLLocationDegrees(exactly: singlePin.longitude ?? 0)
            let newPin = MKPointAnnotation()
            newPin.coordinate = CLLocationCoordinate2D(latitude: lat ?? 0, longitude: long ?? 0)
            newPin.title = "\(singlePin.firstName ?? "") \(singlePin.lastName ?? "" )"
            newPin.subtitle = "\(singlePin.mediaURL ?? "")"
            if !(totalPins.contains(where: { (pin) -> Bool in
                pin.title == newPin.title }))
            { totalPins.append(newPin) }
            
        }
        self.mapView.addAnnotations(totalPins)
        print ( "عدد الدبابيس : \(totalPins.count)" )
        print ( "عدد الدبابيس : \(self.pins.count)" )
        
    }
    
    

    
    
}

extension MapVC: MKMapViewDelegate
{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: "pinId") as? MKPinAnnotationView

        if pinView == nil
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pinId")
            settingAnnotation(pinView)
        }
        else
        {
            pinView?.annotation = annotation
            settingAnnotation( pinView)
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl)
    {

        if control == view.rightCalloutAccessoryView
        {
            guard let detailURL =  URL(string: ((view.annotation?.subtitle)!)!) else { showAlert(message: "Couldn't open the link, check if it's correct. \n لا أستطيع فتح الرابط") ;return }
            UIApplication.shared.open(detailURL, options: [:], completionHandler: nil)
        }
    }
    
}
