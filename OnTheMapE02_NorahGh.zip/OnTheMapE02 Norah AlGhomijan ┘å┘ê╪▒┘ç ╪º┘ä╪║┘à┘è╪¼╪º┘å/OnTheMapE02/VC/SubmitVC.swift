//
//  SubmitVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan on 13/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import  UIKit
import MapKit
import CoreLocation

class SubmitVC : UIViewController
{
    var coordinates: CLLocationCoordinate2D!
    var student : StudentLocation?
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var finishButton: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.mapView.delegate = self;
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        let newPin = MKPointAnnotation()
        
        newPin.coordinate = self.coordinates
        newPin.title = self.student?.mapString
        newPin.subtitle = self.student?.mediaURL
        self.mapView.addAnnotation(newPin)
        
        let region = MKCoordinateRegion(center: coordinates, span: .init(latitudeDelta: 0.1, longitudeDelta: 0.1))
        self.mapView.setRegion(region, animated: true)
    }
    
    @IBAction func finish(_ sender: Any)
    {
        if !( self.student == nil)
        { UdacityAPI.postLocation(student: self.student, completion: handlingPostLocationResponse(error:)) }
        else { showAlert(message: "couldn't post location because there is no student") }
    }
    
    func handlingPostLocationResponse ( error: Error? )
    {   //5
        guard let error = error else
        {   self.dismiss(animated: true, completion: nil)
            return }
        self.showAlert(message: error.localizedDescription)
    }
    
    
}

extension SubmitVC: MKMapViewDelegate
{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: "pinId") as? MKPinAnnotationView
        
        if pinView == nil
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pinId")
            self.settingAnnotation(pinView)
        }
        else
        {
            pinView?.annotation = annotation
            self.settingAnnotation( pinView)
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl)
    {
        
        if control == view.rightCalloutAccessoryView
        {
            guard let detailURL =  URL(string: ((view.annotation?.subtitle)!)!)
                else { showAlert(message: "Couldn't open the link, check if it's correct. \n لا أستطيع فتح الرابط") ;return }
            UIApplication.shared.open(detailURL, options: [:], completionHandler: nil)
        }
    }
    
}
