//
//  UserInfo.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation

struct UserInfo {
    var firstName: String? = ""
    var lastName: String? = ""
    var sessionId: String? = ""
    var uniqueKey: String? = ""
}
