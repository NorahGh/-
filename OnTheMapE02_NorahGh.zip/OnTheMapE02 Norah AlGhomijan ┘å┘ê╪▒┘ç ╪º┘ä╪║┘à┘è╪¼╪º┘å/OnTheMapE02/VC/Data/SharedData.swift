//
//  SharedData.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 12/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation

class SharedData
{
    static let shared = SharedData()
    
    var pins : [StudentLocation] = []
}
