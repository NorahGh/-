//
//  StudentLocation.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 12/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

//"createdAt": "2015-02-25T01:10:38.103Z",
//"firstName": "Jarrod",
//"lastName": "Parkes",
//"latitude": 34.7303688,
//"longitude": -86.5861037,
//"mapString": "Huntsville, Alabama ",
//"mediaURL": "https://www.linkedin.com/in/jarrodparkes",
//"objectId": "JhOtcRkxsh",
//"uniqueKey": "996618664",
//"updatedAt": "2015-03-09T22:04:50.315Z"

import Foundation

struct StudentLocation : Codable
{
    var createdAt: String? = ""
    var firstName: String? = ""
    var lastName: String? = ""
    var latitude: Double? = 0.0
    var longitude: Double? = 0.0
    var mapString: String? = ""
    var mediaURL: String? = ""
    var objectId: String? = ""
    var uniqueKey: String? = ""
    var updatedAt: String? = ""
    
}
