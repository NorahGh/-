//
//  LoginDataResponse.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation

struct LoginDataResponse: Codable
{
    let account: Account?
    let session: Session?
    let status: Int?
    let error: String?
}

struct Account: Codable
{
    let registered: Bool
    let key: String
}

struct Session: Codable
{
    let id: String
    let expiration: String
}
