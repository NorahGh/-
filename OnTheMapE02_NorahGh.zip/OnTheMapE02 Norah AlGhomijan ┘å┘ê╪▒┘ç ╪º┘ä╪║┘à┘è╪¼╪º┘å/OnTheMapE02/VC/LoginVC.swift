//
//  LoginVC.swift
//  OnTheMapE02
//
//  Created by Norah AlGhomijan  on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit

class LoginVC : UIViewController
{
        
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var passworField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var loading: UIActivityIndicatorView!
    // IBAction : login
    // Outlets: email, password , login button.
    
    var userDefaults = UserDefaults.standard
    
    enum userDefaultsKeys
    {
        case email
        case password
        
        var key: String
        {
            switch self
            {
            case .email : return "email"
            case .password : return "password"
            }
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.settingTextAttibuits()
        self.checkUserDefaults()
        self.view.addSubview(self.loading)
        self.view.bringSubviewToFront(self.loading)
        self.freezeUI(false)
        
    }
    
    
    
    @IBAction func loginPressed(_ sender: Any)
    {
        self.freezeUI(true)
        UdacityAPI.postSession(userName: emailField.text!, password: passworField.text!)
        { (response, data, error) in
            guard let response = response else
            {   self.showAlert(message: "check network connection")
                return }
            
            guard let data = data else
            {   self.showAlert(message: "login failed")
                return }
            
            if response.statusCode >= 200 && response.statusCode < 300
            {   self.setUserDefaults()
                self.performSegue(withIdentifier: "completeLogin", sender: nil) }
            else
            {   self.showAlert(message: "\(data.error!) \n check email and password") }
        }
        self.freezeUI(false)
    }
    
    func settingTextAttibuits ()
    {
        let string = "Don't have an account? sign up."
        let text = NSMutableAttributedString(string: string)
        text.addAttribute(.link, value: "https://auth.udacity.com/sign-up", range: NSRange(location: (string.count - 8), length: 7))
        textView.attributedText = text
    }
    
    func setUserDefaults()
    {
        self.userDefaults.set(emailField.text!, forKey: userDefaultsKeys.email.key)
        self.userDefaults.set(passworField.text!, forKey: userDefaultsKeys.password.key)
    }
    
    func checkUserDefaults ()
    {
        emailField.text = userDefaults.value(forKey: userDefaultsKeys.email.key) as? String ?? ""
        passworField.text = userDefaults.value(forKey: userDefaultsKeys.password.key) as? String ?? ""
    }
    
    func freezeUI (_ freeze: Bool)
    {
        if (freeze)
        {   self.loading.startAnimating()     }
        else {  self.loading.stopAnimating()    }
        
        self.emailField.isUserInteractionEnabled = !freeze
        self.passworField.isUserInteractionEnabled = !freeze
        self.loginButton.isEnabled = !freeze
    }
    
    
}




extension LoginVC: UITextViewDelegate
{
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        UIApplication.shared.open(URL, options: [:], completionHandler: nil)
        return false
    }
}
