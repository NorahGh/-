//
//  URLs.swift
//  OnTheMapE02
//
//  Created by Saud Abdullah on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation

//    Method: https://onthemap-api.udacity.com/v1/session                       POST
//    Method: https://onthemap-api.udacity.com/v1/session                       DELETE
//    Method: https://onthemap-api.udacity.com/v1/users/<user_id>               GET             to retrieve some basic user information
//    Method: https://onthemap-api.udacity.com/v1/StudentLocation               POST
//    Method: https://onthemap-api.udacity.com/v1/StudentLocation/<objectId>    PUT
//    Method: https://onthemap-api.udacity.com/v1/StudentLocation               GET

class URLs
{
    
    var firstName: String? = ""
    var lastName: String? = ""
    var sessionId: String? = ""
    
    enum Endpoints
    {
        static let base = "https://onthemap-api.udacity.com/v1"
        
        case session
        case postLocation
        case userPublicData ( String )
        case retrieveLocations (Int,String)
        
        var stringURL: String
        {
            switch self
            {
            case .session :
                return Endpoints.base + "/session"
            case .postLocation:
                return Endpoints.base + "/StudentLocation"
            case let .userPublicData(key):
                return Endpoints.base + "/users" + "/\(key)"
            case let .retrieveLocations (limit, order):
                return Endpoints.base + "/StudentLocation" + "?limit=\(limit)" + "&order=\(order)"
            }
        }
        
        var url: URL { return URL(string: stringURL)!}
        
    }
}
