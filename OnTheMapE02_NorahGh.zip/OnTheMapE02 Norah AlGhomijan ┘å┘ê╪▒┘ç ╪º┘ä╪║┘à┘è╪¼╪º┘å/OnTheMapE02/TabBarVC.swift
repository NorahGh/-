//
//  NavigationBarVC.swift
//  OnTheMapE02
//
//  Created by Saud Abdullah on 11/06/2019.
//  Copyright © 2019 Norah Gh. All rights reserved.
//

import Foundation
import UIKit

class NavigationBarVC: UIViewController
{
    override func viewDidLoad()
    {
        setupBarLeft ()
        setupBarCenter()
        setupBarRight()
    }
    
    func setupBarLeft()
    {
        let logoutButton = UIButton(type: .system)
        logoutButton.titleLabel?.text = "Logout"
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: logoutButton)
    }
    
    func setupBarCenter()
    {
        navigationItem.title = "On The Map"
    }
    
    func setupBarRight ()
    {
//        let refreshButton = UIButton(type: .custom)
//        let postLocationButton = UIButton(type: .system)
        let reloadButton = UIBarButtonItem(barButtonSystemItem: .refresh, target: (Any).self, action: nil)
        let postLoc = UIBarButtonItem(barButtonSystemItem: .add, target: Any.self, action: nil)
        
        navigationItem.rightBarButtonItems = [reloadButton, postLoc]
        
    }
}
