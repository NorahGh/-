//
//  CustomMemeCell.swift
//  MemeMe1
//
//  Created by juhainah on 28/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import UIKit

class CustomMemeCell: UICollectionViewCell
{
    @IBOutlet weak var memedImageView: UIImageView!
    
}
