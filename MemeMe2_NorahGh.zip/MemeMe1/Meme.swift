//
//  Meme.swift
//  MemeMe1
//
//  Created by juhainah on 19/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import Foundation
import UIKit

struct Meme
{
    let topText: String
    let bottomText: String
    let OriginalImage: UIImage!
    let memedImage: UIImage!
}
