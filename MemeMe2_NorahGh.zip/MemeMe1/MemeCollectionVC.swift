//
//  MemeCollectionVC.swift
//  MemeMe1
//
//  Created by juhainah on 28/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import Foundation
import UIKit

class MemeCollectionVC: UICollectionViewController
{
    // MARK: (properties) الخصائص
    // ---------------------------------------
    var memes: [Meme]!
    {
        // (to return the sent memes array in shared application delegate) لاستعادة مصفوفة الصور المُرسلة في المفوض المشترك لهذا التطبيق

        let obj = UIApplication.shared.delegate
        let appDelegate = obj as! AppDelegate
        return appDelegate.memes
    }
    
    @IBOutlet weak var flowLayout : UICollectionViewFlowLayout!
    @IBOutlet var collection: UICollectionView!
    
    
    
    
    // MARK: (loading & preparing this view controller)  تهيئة شاشة التحكم الحالية..
    // ---------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // (determining the chracterstics of the collection view items) تحديد مواصفات عناصر شاشة التشكيلة..

        let spaceWidth: CGFloat = 3.0
        let spaceHeight: CGFloat = 8.0
        let dimensionWidth: CGFloat = (view.frame.size.width - (spaceWidth * 2)) / 3
        let dimensionHeight: CGFloat = (view.frame.size.height - (spaceHeight * 3)) / 4
        
        flowLayout.minimumInteritemSpacing = spaceWidth
        flowLayout.minimumLineSpacing = spaceHeight
        flowLayout.itemSize = CGSize(width: dimensionWidth, height: dimensionHeight)
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = false
        collection.reloadData()
    }
    
    
    
    
    // MARK: (Delegate Functions) دوال المفوض
    
    
    
    
    // 1 - (Number of sent images in array) عدد الصور المرسلة
    // ---------------------------------------
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return memes.count
    }
    
    
    
    
    // 2 - (assigning data to the reusable cell) تعيين بيانات الخلية المستخدمة
    // ---------------------------------------
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! CustomMemeCell
        
        let meme = self.memes[indexPath.row]
        
        
        // assining the image and the characteristics of the reusable cell, تعيين صورة و مواصفات الخلية المستخدمة

        cell.memedImageView.image = meme.memedImage
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.8
        return cell
    }
    
    
    
    
    
    // 3 - (displaying the selected cell)  استعراض الخلية التي تم اختيارها
    // ---------------------------------------
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let detailVC = storyboard?.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        
        detailVC.memeDetail = self.memes[indexPath.row]
        
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
}
