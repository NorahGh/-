//
//  MemeTabelVC.swift
//  MemeMe1
//
//  Created by juhainah on 28/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import Foundation
import UIKit

class MemeTabelVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    // MARK: (properties) الخصائص
    // ---------------------------------------
    
    var memes: [Meme]!
    {
        // (to return the sent memes array in shared application delegate) لاستعادة مصفوفة الصور المُرسلة في المفوض المشترك لهذا التطبيق
        
        let obj = UIApplication.shared.delegate
        let appDelegate = obj as! AppDelegate
        return appDelegate.memes
    }
    
    @IBOutlet weak var table: UITableView!
    
    
    // MARK: (loading & preparing this view controller)  تهيئة شاشة التحكم الحالية..
    // ---------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        table.reloadData()
    }
    
    
    
    
    // MARK: (Delegate Functions) دوال المفوض

    
    
    
    //  1 - (Number of sent images in array) عدد الصور المرسلة
    // ---------------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.memes.count
    }
    
    
    
    
    
    // 2 - (extracting the sent image from array to assign it to the reusable cell) استخراج الصورة المرسلة من المصفوفة لتعيينها في الخلية المستخدمة.
    // ---------------------------------------
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        // extracting the reusable cell استخراج الخلية المستخدمة
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell")! as! CustomTableViewCell
        
        // extracting the data in the cell from sent memes array and assign it to temporary constant استخراج بيانات الخلية من مصوفة الصور المرسلة و تعيينها في ثابت مؤقت.
       let meme = memes[indexPath.row]
        
        // assining the image and the characteristics of the reusable cell, تعيين صورة و مواصفات الخلية المستخدمة
        
        cell.memedImg.image = meme.memedImage
        cell.memedLabel.text = meme.topText + " " + meme.bottomText
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.8
        
        return cell
        
    }
    
    
    
    
    
    // 3 - (When user select one of the cells, we gonna show the detailed image) حينما يختار المستخدم إحدى الخلايا فسنستعرض له الصورة مفصلةً
    // ---------------------------------------

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        
        detailVC.memeDetail = memes[indexPath.row]
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
 
    
    
    
    
    // 4 - (Determine the height of row) تحديد ارتفاع الصف.
    // ---------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let heightForRow: CGFloat = view.frame.size.height/6
        
        return heightForRow
    }
    
    
}
