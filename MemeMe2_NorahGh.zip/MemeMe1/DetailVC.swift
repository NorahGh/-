//
//  DetailVC.swift
//  MemeMe1
//
//  Created by juhainah on 28/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import Foundation
import UIKit

class DetailVC: UIViewController
{
    // MARK: (properties) الخصائص
    // ---------------------------------------
    
    var memeDetail: Meme!
    
    @IBOutlet weak var memedImageView: UIImageView!
    
    
    
    
    // MARK: (loading & preparing this view controller)  تهيئة شاشة التحكم الحالية..
    // ---------------------------------------
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        self.memedImageView.image = memeDetail.memedImage
    }
    
}
