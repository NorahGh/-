//
//  ViewController.swift
//  MemeMe1
//
//  Created by juhainah on 18/04/2019.
//  Copyright © 2019 juhainah. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate

{
    
    // MARK: (Properties) الخصائص ---------------------------------------

    
    @IBOutlet weak var ImagePickerView: UIImageView!
    @IBOutlet weak var CameraButton: UIBarButtonItem!
    
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var bottomToolBar: UIToolbar!
    
    
    let memeTextAttributes: [NSAttributedString.Key: Any] =
        [
        NSAttributedString.Key.strokeColor:UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth:  -1.7
    ]
    
    
    
    
    // MARK: (loading & preparing this view controller)  تهيئة شاشة التحكم الحالية..
    // ---------------------------------------

    
    override func viewDidLoad()
    {

        super.viewDidLoad()
        
        settingTextFieldText(textField: topTextField, Text: "TOP")
        settingTextFieldText(textField: bottomTextField, Text: "BOTTOM")
        
        shareButton.isEnabled = false
        
    }
    
   
    
    
    // MARK: Viewing App استعراض التطبيق ----------------------------------

    override func viewWillAppear(_ animated: Bool)
    {
        
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        
        CameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        if (!(ImagePickerView!.image == nil))
        {
            shareButton.isEnabled = true
        }
        
        subscribeToKeyboardNotifications()


    }
    
    override func viewWillDisappear(_ animated: Bool)
    {

        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
        
        unsubscribeFromKeyboardNotifications()
    }

    
    
    
    
    // MARK: Notifications التنبيهات ----------------------------------

    func subscribeToKeyboardNotifications ()
    {

        NotificationCenter.default.addObserver(self, selector: #selector( keyboardWillShow(_:) ), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector( keyboardWillHide(_:) ), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications ()
    {

        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)

    }
   
   
    
    
    // MARK: Picking Image انتقاء صورة ----------------------------------

    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        
        if let Image = info [.originalImage] as! UIImage?
        {
            ImagePickerView.image = Image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func pickAnImageFromAlbum(_ sender: Any)
    {

       pickAnImage(sourceType: .photoLibrary)
    }
    
    
    
    @IBAction func pickAnImageFromCamera(_ sender: Any)
    {
       pickAnImage(sourceType: .camera)

    }
    
    
    
    func pickAnImage (sourceType: UIImagePickerController.SourceType)
    {
        let controller = UIImagePickerController()
        controller.delegate = self
        controller.sourceType = sourceType
        present(controller, animated: true, completion: nil)
        
    }
    
    
    
    
    
    // MARK: Share Button زر المشاركة ----------------------------------

    @IBAction func shareImage(_ sender: Any)
    {

        let Image: UIImage = memedImage()
        let controller = UIActivityViewController(activityItems: [Image], applicationActivities: nil)
        
        self.present(controller,animated: true,completion: nil)
        
        controller.completionWithItemsHandler =
            { (activityType, completed, returnedItems, error) in
                if (completed)
                {
                    self.Save ()
                self.navigationController?.popViewController(animated: true)
                }
                controller.dismiss(animated: true, completion: nil)
        }
        
        
    }
    
    
    
    
    // MARK: Editing Image تحرير الصورة ----------------------------------

    func Save ()
    {

        let meme: Meme = Meme(topText:topTextField.text!, bottomText: bottomTextField.text!,OriginalImage: ImagePickerView?.image, memedImage: memedImage())
        
        // save meme in array
        (UIApplication.shared.delegate as! AppDelegate).memes.append(meme)
    }
    
    func memedImage () -> UIImage
    {
        
        bottomToolBar.isHidden = true
        navigationBar.isHidden = true
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage : UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        bottomToolBar.isHidden = false
        navigationBar.isHidden = false
        
        return memedImage
        
    }
    
    
    // MARK: Text Fields النصوص----------------------------------
   
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
       
        textField.placeholder = ""
        textField.textAlignment = .center
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {

        textField.resignFirstResponder()
        return true
    }
    
    
    func settingTextFieldText (textField: UITextField, Text:String)
    {
        textField.delegate = self
        textField.contentHorizontalAlignment = .center
        textField.contentVerticalAlignment = .center
        textField.textAlignment = .center
        textField.defaultTextAttributes = memeTextAttributes
        textField.text = ""
        textField.placeholder = Text
    }
    
    
    
    
    // MARK: Keyboard لوحة المفاتيح ----------------------------------
    
    @objc func keyboardWillShow (_ notification:Notification)
    {
        
        if (bottomTextField.isEditing)
        {
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
    }
    
    
    @objc func keyboardWillHide (_ notification:Notification)
    {
        
        view.frame.origin.y = 0
    }
    
    
    func getKeyboardHeight (_ notification:Notification) -> CGFloat
    {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        
        return keyboardSize.cgRectValue.height
    }
    
    
    
    // MARK: Cancel Button زر الإلغاء ----------------------------------

    @IBAction func cancel(_ sender: Any)
    
    {
        self.navigationController?.popViewController(animated: true)

    }
}

